About:
   It is a simple effect you can use to show pictures on a 
   website

To 'run' a project:
   19-requestAnimationFrame.html