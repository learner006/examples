window.addEventListener("DOMContentLoaded", function () {
         requestAnimationFrame(render_once);
   });

let g_timestamp_start;
const G_ANIMATION_DURATION = 1500; //msec

let cx=200,cy=200,R=290;
let g_prevPt;



function render_once(p_timestamp)
{
/*   let path2 = 'M200,200 L200,100 A100,100 0 1 0 210, 100';
   let e3 = document.getElementById('svg-path');
   e3.setAttribute('d',path2);
   console.log('xxxxxxxxx');
   return;
*/
   /*********************************************************************************
   12 o'clock (cx,cy-R) is the beginning of the arc to count
   OX right, OY down ( just in case ;-) 
   *********************************************************************************/
   function getDeltasForPointOnCircle(p_Radius, p_arcSizeInRadians)
   {
      let xDelta = p_Radius * Math.sin(p_arcSizeInRadians);
      let yDelta = -p_Radius * Math.cos(p_arcSizeInRadians);
      return {x:xDelta,y:yDelta};

   }

   /*********************************************************************************
   let pt = {x:300,y: 200};

   let s = constructSectorSvgPath(200,200,100,0,1,pt);
   // s => 'M200,200 L200,100 A100,100 0 0 1 300,200'

   let s1 = constructSectorSvgPath(200,200,100,1,1,pt);
   // s1 => 'M200,200 L200,100 A100,100 0 1 1 300,200'
   *********************************************************************************/
   function constructSectorSvgPath(p_cx, p_cy, p_R, p_largeArcFlag, p_sweepFlag, p_pt)
   {
      let twelveOClockPt = {x: p_cx, y:(p_cy-p_R)};
      let pt = twelveOClockPt;
      let rotationInDeg = 0; // around OX

      let res = 
         `M${pt.x},${p_cy} L${pt.x},${pt.y} A${p_R},${p_R} ${rotationInDeg} ${p_largeArcFlag} ${p_sweepFlag} ${p_pt.x}, ${p_pt.y}`;

      return res;
         
      return 
         `M${pt.x},${pt.y} L${pt.x},${p_y} A${p_R},${p_R}\
          ${rotationInDeg} ${p_largeArcFlag} ${p_sweepFlag} \
          ${p_pt.x}, ${p_pt.y}`;
   }

   if (g_timestamp_start === undefined)
      g_timestamp_start = p_timestamp;

   let timeAmount = p_timestamp - g_timestamp_start;
   let visiblePartOfSector = timeAmount / G_ANIMATION_DURATION;
   let arcInRadians = 2 * Math.PI * visiblePartOfSector;

   let ptDelta = getDeltasForPointOnCircle(R,arcInRadians);
   let pt = {x: cx + ptDelta.x, y: cy + ptDelta.y};
   pt.x = Math.round(pt.x * 1e4) / 1e4; // do not happy about it
   pt.y = Math.round(pt.y * 1e4) / 1e4;

   if (g_prevPt === undefined)
      g_prevPt = pt;

   // do not think about the first step of algo! ;-)
   const treshold = 1;
   let pointsOnCircleNotEqual = Math.abs(pt.x - g_prevPt.x) >= treshold
       || Math.abs(pt.y - g_prevPt.y) >= treshold;

   if (pointsOnCircleNotEqual)
      g_prevPt = pt;

   let largeArcFlag = visiblePartOfSector < 0.5 ? 1 : 0;
   let sweepFlag = 0;

   let path = constructSectorSvgPath(cx,cy,R,largeArcFlag,sweepFlag,pt);

   const firstTime = (Math.abs(g_timestamp_start - p_timestamp) < 1e-9);
   const needRenderFurther = (p_timestamp - g_timestamp_start <= G_ANIMATION_DURATION);

   if (pointsOnCircleNotEqual || firstTime || !needRenderFurther) {
      let svgPathElem = document.getElementById('svg-path');
      if (svgPathElem) {

         if (pointsOnCircleNotEqual)
            svgPathElem.setAttribute('d',path);

         if (!needRenderFurther)
            svgPathElem.setAttribute('opacity','0');      
         
         if (firstTime) {
            let svgFilledCircle = document.getElementById('svg-filled-circle');
            if (svgFilledCircle)
               svgFilledCircle.setAttribute('fill-opacity','0');

            svgPathElem.setAttribute('opacity','1');
         }
      }
   }

   if (needRenderFurther)
      requestAnimationFrame(render_once);

}











