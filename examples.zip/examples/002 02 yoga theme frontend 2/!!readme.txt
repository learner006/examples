About:
   It is a website that says about my skills. I created it 
   with India in the heart.
   
Video presentation:
   yougatheme.mp4

To 'run' a project (Windows):
   1) You need a PHP interpreter
   2) cd ./dist
   3) run env.bat
   4) go to http://localhost:8264/07-yoga-theme4.html

To 'compile' a project:
   1) Use pugjs
   2) cd src
   3) 07-yoga-theme4.pug


















