About:
   It is a site of a small local shop located in a cozy place.

To 'run' a project:
   dist/factory-shop3.html

To 'compile' a project:
   1) Use pugjs
   2) cd ./src
   3) factory-shop3.pug