About:
   It is a presentation of my super-skills! :-) It uses 
   masonry layout (and responsive design).

To 'run' a project:
   ./project-card.html